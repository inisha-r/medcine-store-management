AOS.init({
    offset: 200,
    duration: 200,
    easing: 'ease-in-quad',
    delay: 200,
});

